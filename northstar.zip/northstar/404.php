<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main id="primary" class="site-main ns-container ns-section" style="text-align:center;">
	<h1><?php esc_html_e( 'This page could not be found', 'northstar' ); ?></h1>
	<div style="max-width:30em;margin-inline:auto;"><?php get_search_form(); ?></div>
	<p style="margin-top:2rem;"><a class="ns-btn ns-btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to homepage', 'northstar' ); ?></a></p>
</main>
<?php get_footer(); ?>
