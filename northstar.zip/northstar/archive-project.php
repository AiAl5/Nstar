<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main id="primary" class="site-main ns-container ns-section">
	<header class="ns-section-head"><span class="ns-eyebrow"><?php esc_html_e( 'Portfolio', 'northstar' ); ?></span><h1><?php esc_html_e( 'Projects', 'northstar' ); ?></h1></header>
	<?php get_template_part( 'template-parts/project-archive-loop' ); ?>
</main>
<?php get_footer(); ?>
