<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main id="primary" class="site-main ns-container ns-section">
	<header class="ns-section-head"><h1><?php the_archive_title(); ?></h1><?php the_archive_description( '<div class="ns-lede">', '</div>' ); ?></header>
	<div class="ns-layout <?php echo is_active_sidebar( 'sidebar-1' ) ? 'has-sidebar' : ''; ?>">
		<div>
			<?php if ( have_posts() ) : ?>
				<div class="ns-grid ns-grid--2"><?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content' ); endwhile; ?></div>
				<?php northstar_pagination(); ?>
			<?php else : ?>
				<?php get_template_part( 'template-parts/content', 'none' ); ?>
			<?php endif; ?>
		</div>
		<?php get_sidebar(); ?>
	</div>
</main>
<?php get_footer(); ?>
