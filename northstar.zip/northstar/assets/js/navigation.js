(function(){
"use strict";
document.addEventListener("DOMContentLoaded",function(){
 var toggle=document.querySelector(".menu-toggle");
 var nav=document.getElementById("primary-menu-wrapper");
 if(toggle&&nav){toggle.addEventListener("click",function(){
   var isOpen=nav.classList.toggle("is-open");
   toggle.setAttribute("aria-expanded",isOpen?"true":"false");
 });}
});
})();
