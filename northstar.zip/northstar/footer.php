<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
	<footer id="colophon" class="site-footer">
		<div class="ns-container site-footer__grid">
			<div><p class="site-title"><?php bloginfo( 'name' ); ?></p><p><?php bloginfo( 'description' ); ?></p></div>
			<?php if ( is_active_sidebar( 'footer-1' ) ) : dynamic_sidebar( 'footer-1' ); endif; ?>
			<?php if ( is_active_sidebar( 'footer-2' ) ) : dynamic_sidebar( 'footer-2' ); endif; ?>
			<?php if ( is_active_sidebar( 'footer-3' ) ) : dynamic_sidebar( 'footer-3' ); endif; ?>
		</div>
		<div class="ns-container site-footer__bottom">
			<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'northstar' ); ?></p>
			<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'depth' => 1, 'fallback_cb' => false ) ); ?>
		</div>
	</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>
