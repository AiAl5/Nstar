<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$eyebrow = get_theme_mod( 'northstar_hero_eyebrow', __( 'Digital projects & research', 'northstar' ) );
$heading = get_theme_mod( 'northstar_hero_heading', __( 'Careful, curious work at the edge of design and code.', 'northstar' ) );
$sub = get_theme_mod( 'northstar_hero_subheading', __( 'Northstar is a home base for the projects, tools and long-form research from a small independent studio.', 'northstar' ) );
?>
<main id="primary" class="site-main">
	<section class="ns-hero">
		<div class="ns-container ns-hero__grid">
			<div>
				<span class="ns-eyebrow"><?php echo esc_html( $eyebrow ); ?></span>
				<h1><?php echo esc_html( $heading ); ?></h1>
				<p class="ns-lede"><?php echo esc_html( $sub ); ?></p>
				<div class="ns-hero__actions">
					<a class="ns-btn ns-btn--primary" href="<?php echo esc_url( get_post_type_archive_link( 'project' ) ? get_post_type_archive_link( 'project' ) : home_url( '/' ) ); ?>"><?php esc_html_e( 'View the work', 'northstar' ); ?></a>
					<a class="ns-btn ns-btn--secondary" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Start a project', 'northstar' ); ?></a>
				</div>
			</div>
		</div>
	</section>
	<?php $projects = new WP_Query( array( 'post_type' => 'project', 'posts_per_page' => 3, 'ignore_sticky_posts' => true, 'no_found_rows' => true ) ); if ( $projects->have_posts() ) : ?>
		<section class="ns-section">
			<div class="ns-container">
				<div class="ns-section-head"><span class="ns-eyebrow"><?php esc_html_e( 'Selected work', 'northstar' ); ?></span><h2><?php esc_html_e( 'Recent projects', 'northstar' ); ?></h2></div>
				<div class="ns-grid ns-grid--3"><?php while ( $projects->have_posts() ) : $projects->the_post(); get_template_part( 'template-parts/project-card' ); endwhile; wp_reset_postdata(); ?></div>
			</div>
		</section>
	<?php endif; ?>
	<section class="ns-section ns-section--tight" style="background:#fff;border-top:1px solid var(--ns-border);border-bottom:1px solid var(--ns-border);">
		<div class="ns-container">
			<div class="ns-section-head"><span class="ns-eyebrow"><?php esc_html_e( 'What we do', 'northstar' ); ?></span><h2><?php esc_html_e( 'Services', 'northstar' ); ?></h2></div>
			<div class="ns-grid ns-grid--3">
				<div class="ns-card"><div class="ns-card__body"><h3 class="ns-card__title"><?php esc_html_e( 'Product design', 'northstar' ); ?></h3><p class="ns-card__excerpt"><?php esc_html_e( 'Interfaces and interaction design from concept to prototype.', 'northstar' ); ?></p></div></div>
				<div class="ns-card"><div class="ns-card__body"><h3 class="ns-card__title"><?php esc_html_e( 'Front-end development', 'northstar' ); ?></h3><p class="ns-card__excerpt"><?php esc_html_e( 'Accessible, performant builds for the web.', 'northstar' ); ?></p></div></div>
				<div class="ns-card"><div class="ns-card__body"><h3 class="ns-card__title"><?php esc_html_e( 'Research & writing', 'northstar' ); ?></h3><p class="ns-card__excerpt"><?php esc_html_e( 'Independent research and long-form articles.', 'northstar' ); ?></p></div></div>
			</div>
		</div>
	</section>
	<?php $articles = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 3, 'ignore_sticky_posts' => true, 'no_found_rows' => true ) ); if ( $articles->have_posts() ) : ?>
		<section class="ns-section">
			<div class="ns-container">
				<div class="ns-section-head"><span class="ns-eyebrow"><?php esc_html_e( 'From the journal', 'northstar' ); ?></span><h2><?php esc_html_e( 'Recent research & writing', 'northstar' ); ?></h2></div>
				<div class="ns-grid ns-grid--3"><?php while ( $articles->have_posts() ) : $articles->the_post(); get_template_part( 'template-parts/blog-card' ); endwhile; wp_reset_postdata(); ?></div>
			</div>
		</section>
	<?php endif; ?>
	<section class="ns-section">
		<div class="ns-container">
			<div class="ns-cta">
				<h2><?php esc_html_e( 'Have a project in mind?', 'northstar' ); ?></h2>
				<p class="ns-lede" style="margin-inline:auto;"><?php esc_html_e( 'Tell us about it -- we read every message and reply personally.', 'northstar' ); ?></p>
				<a class="ns-btn ns-btn--primary" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Get in touch', 'northstar' ); ?></a>
			</div>
		</div>
	</section>
</main>
<?php get_footer(); ?>
