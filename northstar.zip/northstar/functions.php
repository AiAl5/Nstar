<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
define( 'NORTHSTAR_VERSION', '1.0.0' );
define( 'NORTHSTAR_DIR', get_template_directory() );
define( 'NORTHSTAR_URI', get_template_directory_uri() );
foreach ( array( '/inc/setup.php', '/inc/enqueue.php', '/inc/template-tags.php', '/inc/template-functions.php', '/inc/customizer.php', '/inc/widgets.php', '/inc/icons.php', '/inc/class-northstar-nav-walker.php', '/inc/custom-post-types.php', '/inc/security.php' ) as $northstar_file ) {
	$northstar_path = NORTHSTAR_DIR . $northstar_file;
	if ( is_readable( $northstar_path ) ) { require_once $northstar_path; }
}
unset( $northstar_file, $northstar_path );
