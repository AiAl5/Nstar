<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'northstar' ); ?></a>
<div id="page" class="site">
<header id="masthead" class="site-header">
	<div class="ns-container site-header__inner">
		<div class="site-branding">
			<?php if ( has_custom_logo() ) { the_custom_logo(); } else { ?>
				<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
				<p class="site-description"><?php bloginfo( 'description' ); ?></p>
			<?php } ?>
		</div>
		<button class="menu-toggle" aria-controls="primary-menu-wrapper" aria-expanded="false">
			<?php echo northstar_get_icon( 'menu' ); ?><span><?php esc_html_e( 'Menu', 'northstar' ); ?></span>
		</button>
		<nav id="primary-menu-wrapper" class="primary-navigation" aria-label="<?php esc_attr_e( 'Primary', 'northstar' ); ?>">
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'primary-menu', 'menu_class' => 'primary-menu', 'container' => false, 'walker' => new Northstar_Nav_Walker(), 'fallback_cb' => false ) ); ?>
		</nav>
	</div>
</header>
