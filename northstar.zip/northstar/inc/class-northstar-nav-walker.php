<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! class_exists( 'Northstar_Nav_Walker' ) ) {
	class Northstar_Nav_Walker extends Walker_Nav_Menu {
		public function start_lvl( &$output, $depth = 0, $args = null ) {
			$output .= '<ul class="sub-menu">';
		}
		public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
			$classes = empty( $item->classes ) ? array() : (array) $item->classes;
			$class_names = join( ' ', array_filter( array_map( 'sanitize_html_class', $classes ) ) );
			$output .= '<li class="' . esc_attr( $class_names ) . '">';
			$output .= '<a href="' . esc_url( $item->url ) . '">' . esc_html( apply_filters( 'the_title', $item->title, $item->ID ) ) . '</a>';
		}
	}
}
