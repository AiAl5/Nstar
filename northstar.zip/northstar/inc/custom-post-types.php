<?php
/**
 * "Project" post type. NOTE: registering this in the theme (rather than a
 * companion plugin) is the common ThemeForest approach but ties project
 * data to the theme; see readme.txt for the plugin-territory trade-off.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
function northstar_register_project_post_type() {
	register_post_type( 'project', array(
		'labels' => array( 'name' => __( 'Projects', 'northstar' ), 'singular_name' => __( 'Project', 'northstar' ), 'add_new_item' => __( 'Add New Project', 'northstar' ), 'all_items' => __( 'All Projects', 'northstar' ) ),
		'public' => true, 'show_in_rest' => true, 'has_archive' => true, 'menu_icon' => 'dashicons-portfolio',
		'rewrite' => array( 'slug' => 'projects' ),
		'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
	) );
	register_taxonomy( 'project_category', 'project', array(
		'labels' => array( 'name' => __( 'Project Categories', 'northstar' ) ), 'hierarchical' => true, 'show_in_rest' => true, 'rewrite' => array( 'slug' => 'project-category' ),
	) );
}
add_action( 'init', 'northstar_register_project_post_type' );
function northstar_register_project_meta() {
	foreach ( array( 'northstar_project_client', 'northstar_project_url', 'northstar_project_year' ) as $key ) {
		register_post_meta( 'project', $key, array( 'type' => 'string', 'single' => true, 'show_in_rest' => true, 'sanitize_callback' => 'sanitize_text_field', 'auth_callback' => function () { return current_user_can( 'edit_posts' ); } ) );
	}
}
add_action( 'init', 'northstar_register_project_meta' );
function northstar_add_project_meta_box() {
	add_meta_box( 'northstar_project_details', esc_html__( 'Project Details', 'northstar' ), 'northstar_render_project_meta_box', 'project', 'side' );
}
add_action( 'add_meta_boxes', 'northstar_add_project_meta_box' );
function northstar_render_project_meta_box( $post ) {
	wp_nonce_field( 'northstar_save_project_meta', 'northstar_project_meta_nonce' );
	$client = get_post_meta( $post->ID, 'northstar_project_client', true );
	$url = get_post_meta( $post->ID, 'northstar_project_url', true );
	$year = get_post_meta( $post->ID, 'northstar_project_year', true );
	echo '<p><label>' . esc_html__( 'Client', 'northstar' ) . '<input type="text" name="northstar_project_client" class="widefat" value="' . esc_attr( $client ) . '"></label></p>';
	echo '<p><label>' . esc_html__( 'Live URL', 'northstar' ) . '<input type="url" name="northstar_project_url" class="widefat" value="' . esc_attr( $url ) . '"></label></p>';
	echo '<p><label>' . esc_html__( 'Year', 'northstar' ) . '<input type="text" name="northstar_project_year" class="widefat" maxlength="4" value="' . esc_attr( $year ) . '"></label></p>';
}
function northstar_save_project_meta( $post_id ) {
	if ( ! isset( $_POST['northstar_project_meta_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['northstar_project_meta_nonce'] ) ), 'northstar_save_project_meta' ) ) { return; }
	if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }
	foreach ( array( 'northstar_project_client', 'northstar_project_url', 'northstar_project_year' ) as $field ) {
		if ( ! isset( $_POST[ $field ] ) ) { continue; }
		$raw = wp_unslash( $_POST[ $field ] );
		update_post_meta( $post_id, $field, 'northstar_project_url' === $field ? esc_url_raw( $raw ) : sanitize_text_field( $raw ) );
	}
}
add_action( 'save_post_project', 'northstar_save_project_meta' );
