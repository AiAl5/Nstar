<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function northstar_customize_register( $wp_customize ) {
	$wp_customize->add_section( 'northstar_homepage_section', array( 'title' => esc_html__( 'Northstar: Homepage Content', 'northstar' ), 'priority' => 35 ) );
	$wp_customize->add_setting( 'northstar_hero_eyebrow', array( 'default' => esc_html__( 'Digital projects & research', 'northstar' ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'northstar_hero_eyebrow', array( 'label' => esc_html__( 'Hero eyebrow text', 'northstar' ), 'section' => 'northstar_homepage_section', 'type' => 'text' ) );
	$wp_customize->add_setting( 'northstar_hero_heading', array( 'default' => esc_html__( 'Careful, curious work at the edge of design and code.', 'northstar' ), 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'northstar_hero_heading', array( 'label' => esc_html__( 'Hero heading', 'northstar' ), 'section' => 'northstar_homepage_section', 'type' => 'text' ) );
	$wp_customize->add_setting( 'northstar_hero_subheading', array( 'default' => esc_html__( 'Northstar is a home base for the projects, tools and long-form research from a small independent studio.', 'northstar' ), 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'northstar_hero_subheading', array( 'label' => esc_html__( 'Hero supporting text', 'northstar' ), 'section' => 'northstar_homepage_section', 'type' => 'textarea' ) );
	$wp_customize->add_section( 'northstar_social_section', array( 'title' => esc_html__( 'Northstar: Social Links', 'northstar' ), 'priority' => 40 ) );
	foreach ( array( 'twitter' => 'X / Twitter', 'github' => 'GitHub', 'linkedin' => 'LinkedIn' ) as $key => $label ) {
		$id = 'northstar_social_' . $key;
		$wp_customize->add_setting( $id, array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
		$wp_customize->add_control( $id, array( 'label' => sprintf( esc_html__( '%s URL', 'northstar' ), $label ), 'section' => 'northstar_social_section', 'type' => 'url' ) );
	}
}
add_action( 'customize_register', 'northstar_customize_register' );
