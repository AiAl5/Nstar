<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function northstar_scripts() {
	wp_enqueue_style( 'northstar-style', get_stylesheet_uri(), array(), NORTHSTAR_VERSION );
	wp_style_add_data( 'northstar-style', 'rtl', 'replace' );
	wp_enqueue_script( 'northstar-navigation', NORTHSTAR_URI . '/assets/js/navigation.js', array(), NORTHSTAR_VERSION, true );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) { wp_enqueue_script( 'comment-reply' ); }
}
add_action( 'wp_enqueue_scripts', 'northstar_scripts' );
