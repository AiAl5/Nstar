<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function northstar_get_icon( $name ) {
	$icons = array(
		'menu' => '<path d="M3 6h18M3 12h18M3 18h18"/>',
		'arrow' => '<path d="M5 12h14M13 6l6 6-6 6"/>',
		'search' => '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
	);
	if ( ! isset( $icons[ $name ] ) ) { return ''; }
	return sprintf( '<svg xmlns="http://www.w3.org/2000/svg" class="ns-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%s</svg>', $icons[ $name ] );
}
