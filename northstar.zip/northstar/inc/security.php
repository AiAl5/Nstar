<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_filter( 'the_generator', '__return_empty_string' );
add_action( 'init', function () {
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
} );
