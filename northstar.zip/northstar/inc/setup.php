<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function northstar_setup() {
	load_theme_textdomain( 'northstar', NORTHSTAR_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 1200, 800, true );
	add_image_size( 'northstar-card', 800, 600, true );
	add_image_size( 'northstar-hero', 1600, 900, true );
	register_nav_menus( array( 'primary' => esc_html__( 'Primary Menu', 'northstar' ), 'footer' => esc_html__( 'Footer Menu', 'northstar' ) ) );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 240, 'flex-height' => true, 'flex-width' => true ) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/editor-style.css' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	$GLOBALS['content_width'] = apply_filters( 'northstar_content_width', 760 );
}
add_action( 'after_setup_theme', 'northstar_setup' );
