<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function northstar_body_classes( $classes ) {
	$classes[] = ( is_active_sidebar( 'sidebar-1' ) && ! is_front_page() ) ? 'has-sidebar' : 'no-sidebar';
	return $classes;
}
add_filter( 'body_class', 'northstar_body_classes' );
function northstar_excerpt_length( $length ) { return 30; }
add_filter( 'excerpt_length', 'northstar_excerpt_length' );
