<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function northstar_posted_on() {
	$t = sprintf( '<time class="entry-date published" datetime="%1$s">%2$s</time>', esc_attr( get_the_date( DATE_W3C ) ), esc_html( get_the_date() ) );
	echo '<span class="ns-meta__date">' . wp_kses( $t, array( 'time' => array( 'class' => array(), 'datetime' => array() ) ) ) . '</span>';
}
function northstar_posted_by() {
	printf( '<span>%1$s <a href="%2$s">%3$s</a></span>', esc_html__( 'by', 'northstar' ), esc_url( get_author_posts_url( (int) get_the_author_meta( 'ID' ) ) ), esc_html( get_the_author() ) );
}
function northstar_entry_categories() {
	$cats = get_the_category();
	if ( empty( $cats ) ) { return; }
	foreach ( $cats as $i => $cat ) {
		if ( $i > 0 ) { echo ', '; }
		printf( '<a href="%1$s" class="ns-badge">%2$s</a>', esc_url( get_category_link( $cat->term_id ) ), esc_html( $cat->name ) );
	}
}
function northstar_breadcrumbs() {
	if ( is_front_page() ) { return; }
	echo '<nav class="ns-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'northstar' ) . '">';
	printf( '<a href="%1$s">%2$s</a>', esc_url( home_url( '/' ) ), esc_html__( 'Home', 'northstar' ) );
	echo ' / <span aria-current="page">' . esc_html( wp_strip_all_tags( is_singular() ? get_the_title() : get_the_archive_title() ) ) . '</span>';
	echo '</nav>';
}
function northstar_pagination() {
	the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => esc_html__( 'Previous', 'northstar' ), 'next_text' => esc_html__( 'Next', 'northstar' ), 'class' => 'ns-pagination' ) );
}
function northstar_related_items( $post_id, $post_type = 'post', $count = 3 ) {
	$tax = 'post' === $post_type ? 'category' : 'project_category';
	$terms = wp_get_post_terms( $post_id, $tax, array( 'fields' => 'ids' ) );
	if ( is_wp_error( $terms ) || empty( $terms ) ) { return; }
	$q = new WP_Query( array( 'post_type' => $post_type, 'posts_per_page' => absint( $count ), 'post__not_in' => array( absint( $post_id ) ), 'ignore_sticky_posts' => true, 'no_found_rows' => true, 'tax_query' => array( array( 'taxonomy' => $tax, 'field' => 'term_id', 'terms' => $terms ) ) ) );
	if ( ! $q->have_posts() ) { wp_reset_postdata(); return; }
	echo '<section class="ns-section ns-section--tight"><h2>' . esc_html__( 'You might also like', 'northstar' ) . '</h2><div class="ns-grid ns-grid--3">';
	while ( $q->have_posts() ) { $q->the_post(); get_template_part( 'project' === $post_type ? 'template-parts/project-card' : 'template-parts/blog-card' ); }
	echo '</div></section>';
	wp_reset_postdata();
}
function northstar_placeholder_media( $label = '' ) {
	echo '<div class="ns-card__placeholder" aria-hidden="true">' . esc_html( $label ? $label : __( 'Image', 'northstar' ) ) . '</div>';
}
