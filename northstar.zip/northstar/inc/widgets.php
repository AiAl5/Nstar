<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function northstar_widgets_init() {
	register_sidebar( array( 'name' => esc_html__( 'Blog Sidebar', 'northstar' ), 'id' => 'sidebar-1', 'before_widget' => '<div id="%1$s" class="widget %2$s">', 'after_widget' => '</div>', 'before_title' => '<h2 class="widget-title">', 'after_title' => '</h2>' ) );
	foreach ( array( 'footer-1' => 'Footer Column 1', 'footer-2' => 'Footer Column 2', 'footer-3' => 'Footer Column 3' ) as $id => $name ) {
		register_sidebar( array( 'name' => $name, 'id' => $id, 'before_widget' => '<div id="%1$s" class="widget %2$s">', 'after_widget' => '</div>', 'before_title' => '<h2>', 'after_title' => '</h2>' ) );
	}
}
add_action( 'widgets_init', 'northstar_widgets_init' );
