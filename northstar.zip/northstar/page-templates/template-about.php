<?php
/**
 * Template Name: Northstar: About Layout
 * @package Northstar
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post(); ?>
	<main id="primary" class="site-main">
		<header class="ns-hero" style="padding-block:4.5rem;"><div class="ns-container ns-container--narrow"><?php northstar_breadcrumbs(); ?><span class="ns-eyebrow"><?php esc_html_e( 'About', 'northstar' ); ?></span><h1><?php the_title(); ?></h1></div></header>
		<div class="ns-section ns-section--tight"><div class="entry-content ns-container"><?php the_content(); ?></div></div>
	</main>
	<?php
endwhile;
get_footer();
