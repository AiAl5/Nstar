<?php
/**
 * Template Name: Northstar: Contact Layout
 * Description: Northstar does not include a PHP mail-processing form (plugin territory). Install a form plugin and place its shortcode/block in the page content.
 * @package Northstar
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post(); ?>
	<main id="primary" class="site-main ns-container ns-section">
		<header class="ns-article-header"><?php northstar_breadcrumbs(); ?><span class="ns-eyebrow"><?php esc_html_e( 'Contact', 'northstar' ); ?></span><h1><?php the_title(); ?></h1></header>
		<div class="entry-content">
			<?php if ( get_the_content() ) { the_content(); } else { ?>
				<p><strong><?php esc_html_e( 'Email', 'northstar' ); ?>:</strong> <a href="mailto:hello@example.com">hello@example.com</a></p>
			<?php } ?>
			<div class="ns-alert ns-alert--info"><p style="margin-bottom:0;"><?php esc_html_e( 'Install a form plugin (Contact Form 7, WPForms, Jetpack Forms) and add its shortcode/block here.', 'northstar' ); ?></p></div>
		</div>
	</main>
	<?php
endwhile;
get_footer();
