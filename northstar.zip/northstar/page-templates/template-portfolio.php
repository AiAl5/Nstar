<?php
/**
 * Template Name: Northstar: Portfolio Landing
 * @package Northstar
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post(); ?>
	<main id="primary" class="site-main">
		<header class="ns-section ns-section--tight"><div class="ns-container"><?php northstar_breadcrumbs(); ?><span class="ns-eyebrow"><?php esc_html_e( 'Portfolio', 'northstar' ); ?></span><h1><?php the_title(); ?></h1></div></header>
		<div class="ns-container ns-section ns-section--tight">
			<?php $q = new WP_Query( array( 'post_type' => 'project', 'posts_per_page' => get_option( 'posts_per_page' ), 'paged' => max( 1, get_query_var( 'paged' ) ) ) ); if ( $q->have_posts() ) : ?>
				<div class="ns-grid ns-grid--3"><?php while ( $q->have_posts() ) : $q->the_post(); get_template_part( 'template-parts/project-card' ); endwhile; ?></div>
				<?php wp_reset_postdata(); ?>
			<?php else : ?>
				<p><?php esc_html_e( 'No projects have been published yet.', 'northstar' ); ?></p>
			<?php endif; ?>
		</div>
	</main>
	<?php
endwhile;
get_footer();
