<?php
/**
 * Template Name: Northstar: Services Layout
 * @package Northstar
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post(); ?>
	<main id="primary" class="site-main">
		<header class="ns-section ns-section--tight"><div class="ns-container"><?php northstar_breadcrumbs(); ?><span class="ns-eyebrow"><?php esc_html_e( 'Services', 'northstar' ); ?></span><h1><?php the_title(); ?></h1></div></header>
		<div class="ns-container ns-section ns-section--tight"><div class="entry-content" style="max-width:var(--ns-container);"><?php the_content(); ?></div></div>
	</main>
	<?php
endwhile;
get_footer();
