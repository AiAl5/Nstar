=== Northstar ===
Contributors: yourstudioname
Tags: blog, portfolio, one-column, two-columns, right-sidebar, custom-logo, custom-menu, custom-colors, editor-style, featured-images, translation-ready, accessibility-ready
Requires at least: 6.4
Tested up to: 6.6
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A modern editorial WordPress theme for freelancers, creative studios, developers and researchers.

== Installation ==
1. Appearance > Themes > Add New > Upload Theme > select northstar.zip > Install Now > Activate.
2. Appearance > Menus: assign a Primary and Footer menu.
3. Appearance > Customize: set logo, hero text, social links.
4. Settings > Reading: choose a static homepage (front-page.php renders automatically).

== Architecture note on the "Project" post type ==
Registered directly in the theme (inc/custom-post-types.php) -- standard for ThemeForest
portfolio themes, but it ties project content to this theme. For guaranteed long-term
data portability across any theme, move this registration into a companion plugin instead.

== Contact forms ==
Northstar does not include a PHP mail-processing contact form; that is plugin territory.
Use the Contact page template and paste a form plugin's shortcode/block into the content.

== Copyright ==
Northstar WordPress Theme, Copyright 2026 Your Studio Name.
Distributed under the GNU General Public License v2 or later.
Bundles original inline SVG icons (GPLv2-or-later) and no external icon fonts,
JS libraries, or CSS frameworks.
