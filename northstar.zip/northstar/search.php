<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main id="primary" class="site-main ns-container ns-section">
	<header class="ns-section-head"><h1><?php printf( esc_html__( 'Results for: %s', 'northstar' ), '<span>' . esc_html( get_search_query() ) . '</span>' ); ?></h1><?php get_search_form(); ?></header>
	<?php if ( have_posts() ) : ?>
		<div class="ns-grid ns-grid--2"><?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/content', 'search' ); endwhile; ?></div>
		<?php northstar_pagination(); ?>
	<?php else : ?>
		<?php get_template_part( 'template-parts/content', 'none' ); ?>
	<?php endif; ?>
</main>
<?php get_footer(); ?>
