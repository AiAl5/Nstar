<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="s"><?php esc_html_e( 'Search for:', 'northstar' ); ?></label>
	<input type="search" id="s" name="s" class="search-form__field" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Search…', 'northstar' ); ?>">
	<button type="submit" class="ns-btn ns-btn--primary"><?php echo northstar_get_icon( 'search' ); ?><span class="screen-reader-text"><?php esc_html_e( 'Search', 'northstar' ); ?></span></button>
</form>
