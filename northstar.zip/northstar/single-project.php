<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post();
	$client = get_post_meta( get_the_ID(), 'northstar_project_client', true );
	$url = get_post_meta( get_the_ID(), 'northstar_project_url', true );
	?>
	<main id="primary" class="site-main ns-container ns-section">
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<header class="entry-header ns-article-header">
				<?php northstar_breadcrumbs(); ?>
				<span class="ns-eyebrow"><?php esc_html_e( 'Project', 'northstar' ); ?></span>
				<h1><?php the_title(); ?></h1>
				<?php if ( $client ) : ?><div class="ns-meta"><span><?php esc_html_e( 'Client:', 'northstar' ); ?> <?php echo esc_html( $client ); ?></span></div><?php endif; ?>
			</header>
			<?php if ( has_post_thumbnail() ) : ?><div class="ns-article-media"><?php the_post_thumbnail( 'northstar-hero' ); ?></div><?php endif; ?>
			<div class="entry-content"><?php the_content(); ?></div>
			<?php if ( $url ) : ?><p class="ns-container--narrow" style="margin-inline:auto;"><a class="ns-btn ns-btn--primary" href="<?php echo esc_url( $url ); ?>" rel="noopener" target="_blank"><?php esc_html_e( 'Visit live project', 'northstar' ); ?></a></p><?php endif; ?>
			<?php northstar_related_items( get_the_ID(), 'project', 3 ); ?>
		</article>
	</main>
	<?php
endwhile;
get_footer();
