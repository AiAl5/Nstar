<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post();
	?>
	<main id="primary" class="site-main ns-container ns-section">
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<header class="entry-header ns-article-header">
				<?php northstar_breadcrumbs(); ?>
				<span class="ns-eyebrow"><?php northstar_entry_categories(); ?></span>
				<h1><?php the_title(); ?></h1>
				<div class="ns-meta"><?php northstar_posted_by(); ?><?php northstar_posted_on(); ?></div>
			</header>
			<?php if ( has_post_thumbnail() ) : ?><div class="ns-article-media"><?php the_post_thumbnail( 'northstar-hero' ); ?></div><?php endif; ?>
			<div class="entry-content"><?php the_content(); ?></div>
			<nav class="post-navigation">
				<?php $prev = get_previous_post(); $next = get_next_post(); ?>
				<div><?php if ( $prev ) : ?><a href="<?php echo esc_url( get_permalink( $prev ) ); ?>"><?php echo esc_html( get_the_title( $prev ) ); ?></a><?php endif; ?></div>
				<div class="nav-next"><?php if ( $next ) : ?><a href="<?php echo esc_url( get_permalink( $next ) ); ?>"><?php echo esc_html( get_the_title( $next ) ); ?></a><?php endif; ?></div>
			</nav>
			<?php northstar_related_items( get_the_ID(), 'post', 3 ); ?>
		</article>
		<?php if ( comments_open() || get_comments_number() ) { comments_template(); } ?>
	</main>
	<?php
endwhile;
get_footer();
