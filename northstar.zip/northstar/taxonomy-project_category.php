<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$term = get_queried_object();
?>
<main id="primary" class="site-main ns-container ns-section">
	<header class="ns-section-head"><h1><?php echo esc_html( $term->name ); ?></h1></header>
	<?php get_template_part( 'template-parts/project-archive-loop' ); ?>
</main>
<?php get_footer(); ?>
