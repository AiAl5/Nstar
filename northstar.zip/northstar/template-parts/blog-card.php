<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'ns-card' ); ?>>
	<a class="ns-card__media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'northstar-card' ); } else { northstar_placeholder_media( get_the_date( 'M Y' ) ); } ?>
	</a>
	<div class="ns-card__body">
		<div class="ns-meta"><?php northstar_entry_categories(); ?><?php northstar_posted_on(); ?></div>
		<h2 class="ns-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<p class="ns-card__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20 ) ); ?></p>
		<div class="ns-card__footer"><a class="ns-badge" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read article', 'northstar' ); ?></a></div>
	</div>
</article>
