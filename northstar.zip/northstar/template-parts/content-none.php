<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<section class="no-results ns-section">
	<h1><?php esc_html_e( 'Nothing here yet', 'northstar' ); ?></h1>
	<?php get_search_form(); ?>
</section>
