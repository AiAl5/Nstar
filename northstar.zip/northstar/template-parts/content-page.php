<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header ns-article-header"><?php northstar_breadcrumbs(); ?><h1><?php the_title(); ?></h1></header>
	<?php if ( has_post_thumbnail() ) : ?><div class="ns-article-media"><?php the_post_thumbnail( 'northstar-hero' ); ?></div><?php endif; ?>
	<div class="entry-content"><?php the_content(); ?></div>
</article>
