<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_template_part( 'project' === get_post_type() ? 'template-parts/project-card' : 'template-parts/blog-card' );
