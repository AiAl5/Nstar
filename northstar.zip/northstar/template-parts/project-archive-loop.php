<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<?php if ( have_posts() ) : ?>
	<div class="ns-grid ns-grid--3"><?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/project-card' ); endwhile; ?></div>
	<?php northstar_pagination(); ?>
<?php else : ?>
	<?php get_template_part( 'template-parts/content', 'none' ); ?>
<?php endif; ?>
