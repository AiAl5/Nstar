<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$client = get_post_meta( get_the_ID(), 'northstar_project_client', true );
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'ns-card' ); ?>>
	<a class="ns-card__media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'northstar-card' ); } else { northstar_placeholder_media( esc_html__( 'Project', 'northstar' ) ); } ?>
	</a>
	<div class="ns-card__body">
		<h2 class="ns-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<p class="ns-card__excerpt"><?php echo $client ? esc_html( $client ) : esc_html( wp_trim_words( get_the_excerpt(), 18 ) ); ?></p>
		<div class="ns-card__footer"><a class="ns-badge" href="<?php the_permalink(); ?>"><?php esc_html_e( 'View project', 'northstar' ); ?></a></div>
	</div>
</article>
